All files were taken from the web, either from an AI image generating site or from a search engine.

Please do not use or distribute any of the images.
I also did not remove any watermarks, and tried to keep the original images as is.

All rights reserved to:
https://www.craiyon.com/
https://www.svgstud.io/generator.html
and the images I found in DuckDuckGo.
